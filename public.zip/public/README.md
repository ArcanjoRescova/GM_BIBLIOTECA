This folder is the public static folder for the React app. Place `images.jpg` and other assets here.

Example: `public/images.jpg` is referenced by the app.
