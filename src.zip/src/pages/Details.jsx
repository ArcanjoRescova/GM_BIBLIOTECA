import React, { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { dbGetBookById } from '../utils/db'

export default function Details(){
  const { id } = useParams()
  const [book, setBook] = useState(null)

  useEffect(()=>{
    let mounted = true
    ;(async ()=>{
      const b = await dbGetBookById(Number(id))
      if (mounted) setBook(b)
    })()
    return ()=> mounted = false
  },[id])

  if (!book) return (
    <div>
      <h1>Livro não encontrado</h1>
      <Link to="/">Voltar</Link>
    </div>
  )

  return (
    <div>
      <h1>{book.title}</h1>
      <ul>
        <li><strong>Autor:</strong> {book.author || 'Desconhecido'}</li>
        <li><strong>Editora:</strong> {book.publisher || 'Desconhecida'}</li>
        <li><strong>Género:</strong> {book.genre || 'Desconhecido'}</li>
        <li><strong>ISBN:</strong> {book.isbn}</li>
        <li><strong>Ano:</strong> {book.year}</li>
        <li><strong>Edição:</strong> {book.edition}</li>
      </ul>
      <Link to="/">Voltar</Link>
    </div>
  )
}
