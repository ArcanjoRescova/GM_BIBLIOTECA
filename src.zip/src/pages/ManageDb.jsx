import React, { useEffect, useState } from 'react'
import { dbSummary } from '../utils/db'

export default function ManageDb(){
  const [s, setS] = useState(null)
  useEffect(()=>{
    let mounted = true
    ;(async ()=>{
      const summary = await dbSummary()
      if (mounted) setS(summary)
    })()
    return ()=> mounted = false
  },[])

  if (!s) return <div>Carregando...</div>

  return (
    <div>
      <h1>Gerir base de dados (simulado)</h1>
      <ul>
        <li>Livros: {s.books}</li>
        <li>Autores: {s.authors}</li>
        <li>Editoras: {s.publishers}</li>
        <li>Utentes: {s.users}</li>
        <li>Exemplares: {s.copies}</li>
        <li>Requisições: {s.loans}</li>
      </ul>
      <p>Nota: esta interface é estática e não executa SQL no cliente. Para gerir uma base de dados real, adicione um backend ou use Supabase.</p>
    </div>
  )
}
