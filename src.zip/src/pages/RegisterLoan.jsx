import React, {useState, useEffect} from 'react'
import { useNavigate } from 'react-router-dom'
import { dbGetUsers, dbGetCopies, dbAddLoan } from '../utils/db'

export default function RegisterLoan(){
  const [userId, setUserId] = useState('')
  const [copyId, setCopyId] = useState('')
  const navigate = useNavigate()
  const [users, setUsers] = useState([])
  const [copies, setCopies] = useState([])

  useEffect(()=>{
    let mounted = true
    ;(async ()=>{
      const u = await dbGetUsers()
      const c = await dbGetCopies()
      if (mounted) { setUsers(u||[]); setCopies(c||[]) }
    })()
    return ()=> mounted = false
  },[])

  async function submit(e){
    e.preventDefault()
    if (!userId || !copyId) return
    await dbAddLoan({userId: Number(userId), copyId: Number(copyId), date: new Date().toISOString()})
    navigate('/')
  }

  return (
    <div>
      <h1>Registar empréstimo</h1>
      <form onSubmit={submit} className="formgrid">
        <label>Utente<select value={userId} onChange={e=>setUserId(e.target.value)} required>
          <option value="">— Selecionar —</option>
          {users.map(u=>(<option key={u.id} value={u.id}>{u.name}</option>))}
        </select></label>
        <label>Exemplar<select value={copyId} onChange={e=>setCopyId(e.target.value)} required>
          <option value="">— Selecionar —</option>
          {copies.map(c=>(<option key={c.id} value={c.id}>{c.code || ('Cópia ' + c.id)}</option>))}
        </select></label>
        <div className="actions"><button className="btn">Registar</button></div>
      </form>
    </div>
  )
}
