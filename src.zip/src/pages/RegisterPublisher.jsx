import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom'
import { dbAddPublisher } from '../utils/db'

export default function RegisterPublisher(){
  const [name, setName] = useState('')
  const [msg, setMsg] = useState('')
  const navigate = useNavigate()

  async function submit(e){
    e.preventDefault()
    if (!name) { setMsg('Insira o nome da editora.'); return }
    await dbAddPublisher({name})
    navigate('/registar-livro')
  }

  return (
    <div>
      <h1>Registar editora</h1>
      {msg && <div className="alert">{msg}</div>}
      <form onSubmit={submit} className="formgrid">
        <label>Nome<input value={name} onChange={e=>setName(e.target.value)} required/></label>
        <div className="actions"><button className="btn">Registar</button></div>
      </form>
    </div>
  )
}
