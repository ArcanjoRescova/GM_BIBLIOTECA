import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom'
import { dbAddUser } from '../utils/db'

export default function RegisterUser(){
  const [name, setName] = useState('')
  const [nif, setNif] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [address, setAddress] = useState('')
  const [postal, setPostal] = useState('')
  const [msg, setMsg] = useState('')
  const navigate = useNavigate()

  async function submit(e){
    e.preventDefault()
    if (!name) { setMsg('O nome é obrigatório.'); return }
    await dbAddUser({name,nif,email,phone,address,postal})
    navigate('/')
  }

  return (
    <div>
      <h1>Registar utente</h1>
      {msg && <div className="alert">{msg}</div>}
      <form onSubmit={submit} className="formgrid">
        <label>Nome<input value={name} onChange={e=>setName(e.target.value)} required/></label>
        <label>NIF<input value={nif} onChange={e=>setNif(e.target.value)}/></label>
        <label>Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)}/></label>
        <label>Telemóvel<input value={phone} onChange={e=>setPhone(e.target.value)}/></label>
        <label>Morada<input value={address} onChange={e=>setAddress(e.target.value)}/></label>
        <label>Código Postal<input value={postal} onChange={e=>setPostal(e.target.value)}/></label>
        <div className="actions"><button className="btn">Guardar</button></div>
      </form>
    </div>
  )
}
