import React, {useState, useEffect} from 'react'
import { useNavigate } from 'react-router-dom'
import { dbAddBook, dbGetAuthors, dbGetPublishers, dbGetGenres } from '../utils/db'

export default function RegisterBook(){
  const [title, setTitle] = useState('')
  const [isbn, setIsbn] = useState('')
  const [author, setAuthor] = useState('')
  const [publisher, setPublisher] = useState('')
  const [genre, setGenre] = useState('')
  const [year, setYear] = useState('')
  const [edition, setEdition] = useState('')
  const [msg, setMsg] = useState('')
  const navigate = useNavigate()

  const [authors, setAuthors] = useState([])
  const [publishers, setPublishers] = useState([])
  const [genres, setGenres] = useState([])

  useEffect(()=>{
    let mounted = true
    ;(async ()=>{
      const a = await dbGetAuthors()
      const p = await dbGetPublishers()
      const g = await dbGetGenres()
      if (mounted) { setAuthors(a||[]); setPublishers(p||[]); setGenres(g||[]) }
    })()
    return ()=> mounted = false
  },[])

  async function submit(e){
    e.preventDefault()
    if (!title || !genre) { setMsg('Preencha pelo menos o título e o género.'); return }
    await dbAddBook({title,isbn,author: author||null,publisher: publisher||null,genre,year,edition})
    navigate('/')
  }

  return (
    <div>
      <h1>Registar livro</h1>
      {msg && <div className="alert">{msg}</div>}
      <form onSubmit={submit} className="formgrid">
        <label>Título<input value={title} onChange={e=>setTitle(e.target.value)} required/></label>
        <label>ISBN<input value={isbn} onChange={e=>setIsbn(e.target.value)}/></label>
        <label>Autor<select value={author} onChange={e=>setAuthor(e.target.value)}>
          <option value="">— Selecionar —</option>
          {authors.map(a=>(<option key={a.id} value={a.id}>{a.name}</option>))}
        </select></label>
        <label>Editora<select value={publisher} onChange={e=>setPublisher(e.target.value)}>
          <option value="">— Selecionar —</option>
          {publishers.map(p=>(<option key={p.id} value={p.id}>{p.name}</option>))}
        </select></label>
        <label>Género<select value={genre} onChange={e=>setGenre(e.target.value)} required>
          <option value="">— Selecionar —</option>
          {genres.map(g=>(<option key={g} value={g}>{g}</option>))}
        </select></label>
        <label>Ano<input type="number" value={year} onChange={e=>setYear(e.target.value)} min={1000} max={2100}/></label>
        <label>Edição<input value={edition} onChange={e=>setEdition(e.target.value)}/></label>
        <div className="actions"><button className="btn">Guardar</button></div>
      </form>
    </div>
  )
}
