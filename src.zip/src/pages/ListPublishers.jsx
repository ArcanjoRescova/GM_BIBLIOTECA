import React, {useEffect, useState} from 'react'
import { Link } from 'react-router-dom'
import { dbGetPublishers } from '../utils/db'

export default function ListPublishers(){
  const [pubs, setPubs] = useState([])
  useEffect(()=>{
    let mounted = true
    ;(async ()=>{
      const p = await dbGetPublishers()
      if (mounted) setPubs(p||[])
    })()
    return ()=> mounted = false
  },[])
  return (
    <div>
      <h1>Editoras</h1>
      <Link to="/registar-editora" className="btn">Registar editora</Link>
      <ul>
        {pubs.map(p=>(<li key={p.id}>{p.name}</li>))}
      </ul>
    </div>
  )
}
