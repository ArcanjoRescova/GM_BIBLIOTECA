import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom'
import { dbAddPostal } from '../utils/db'

export default function RegisterPostal(){
  const [code, setCode] = useState('')
  const [locality, setLocality] = useState('')
  const navigate = useNavigate()

  async function submit(e){
    e.preventDefault()
    if (!code || !locality) return
    await dbAddPostal({code, locality})
    navigate('/')
  }

  return (
    <div>
      <h1>Registar código postal</h1>
      <form onSubmit={submit} className="formgrid">
        <label>Código<input value={code} onChange={e=>setCode(e.target.value)} required/></label>
        <label>Localidade<input value={locality} onChange={e=>setLocality(e.target.value)} required/></label>
        <div className="actions"><button className="btn">Registar</button></div>
      </form>
    </div>
  )
}
