import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom'
import { dbAddGenre } from '../utils/db'

export default function RegisterGenre(){
  const [genre, setGenre] = useState('')
  const [msg, setMsg] = useState('')
  const navigate = useNavigate()

  async function submit(e){
    e.preventDefault()
    if (!genre) { setMsg('Insira um género.'); return }
    await dbAddGenre(genre)
    navigate('/')
  }

  return (
    <div>
      <h1>Registar género</h1>
      {msg && <div className="alert">{msg}</div>}
      <form onSubmit={submit} className="formgrid">
        <label>Género<input value={genre} onChange={e=>setGenre(e.target.value)} required/></label>
        <div className="actions"><button className="btn">Registar</button></div>
      </form>
    </div>
  )
}
