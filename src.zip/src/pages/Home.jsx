import React, {useState, useEffect} from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { dbGetHighlights, dbSearchBooks } from '../utils/db'

export default function Home(){
  const [searchParams, setSearchParams] = useSearchParams()
  const q = searchParams.get('q') || ''
  const [query, setQuery] = useState(q)
  const [results, setResults] = useState([])
  const [highlights, setHighlights] = useState([])

  useEffect(()=>{
    let mounted = true
    ;(async ()=>{
      const hs = await dbGetHighlights()
      if (mounted) setHighlights(hs)
    })()
    return ()=> mounted = false
  },[])

  useEffect(()=>{
    if (query.trim() === '') {
      setResults([])
      return
    }
    let mounted = true
    ;(async ()=>{
      const rs = await dbSearchBooks(query)
      if (mounted) setResults(rs)
    })()
    return ()=> mounted = false
  },[query])

  return (
    <div>
      <header className="hero">
        <h1>Sistema Bibliotecário</h1>
        <p>Bem-vindo(a) ao Sistema para Controle de Acervo Literário</p>
        <form onSubmit={(e)=>{ e.preventDefault(); const params = {}; if (query) params.q = query; setSearchParams(params) }}>
          <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Pesquisar" />
          <button>Pesquisar</button>
        </form>
      </header>

      <main>
        <section className="kpi-row">
          <div className="kpi green">
            <div className="left">
              <strong>0</strong>
              <small>Empréstimos Mensais</small>
            </div>
            <div className="right">Ver todos</div>
          </div>
          <div className="kpi blue">
            <div className="left">
              <strong>2</strong>
              <small>Acervos cadastrados</small>
            </div>
            <div className="right">Ver todos</div>
          </div>
          <div className="kpi red">
            <div className="left">
              <strong>3</strong>
              <small>Usuários</small>
            </div>
            <div className="right">Ver todos</div>
          </div>
        </section>
        {query.trim() ? (
          <section>
            <h2>Resultados para "{query}"</h2>
            {results.length === 0 ? <div className="alert">Sem resultados</div> : (
              <div className="grid">
                {results.map(b=> (
                  <article key={b.id} className="card">
                    <img src={b.cover || 'https://via.placeholder.com/400x600?text=Sem+capa'} alt="capa" />
                    <h3>{b.title}</h3>
                    <p className="muted">{b.author}</p>
                    <div className="badges"><span className="badge">Disponível</span></div>
                    <Link to={`/detalhes/${b.id}`} className="btn">Ver detalhes</Link>
                  </article>
                ))}
              </div>
            )}
          </section>
        ) : (
          <section>
            <h2>Destaques</h2>
            <div className="grid">
              {highlights.length === 0 ? <div className="alert">Ainda não há livros registados.</div> : highlights.map(b=> (
                <article key={b.id} className="card">
                  <img src={b.cover || 'https://via.placeholder.com/400x600?text=Sem+capa'} alt="capa" />
                  <h3>{b.title}</h3>
                  <p className="muted">{b.author}</p>
                  <div className="badges"><span className="badge">Disponível</span></div>
                  <Link to={`/detalhes/${b.id}`} className="btn">Ver detalhes</Link>
                </article>
              ))}
            </div>
          </section>
        )}
      </main>
    </div>
  )
}
