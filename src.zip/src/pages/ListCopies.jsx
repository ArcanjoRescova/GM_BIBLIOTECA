import React, {useEffect, useState} from 'react'
import { Link } from 'react-router-dom'
import { dbGetCopies, dbGetBooks } from '../utils/db'

export default function ListCopies(){
  const [copies, setCopies] = useState([])
  const [booksMap, setBooksMap] = useState({})
  useEffect(()=>{
    let mounted = true
    ;(async ()=>{
      const c = await dbGetCopies()
      const b = await dbGetBooks()
      const map = {}
      (b||[]).forEach(x=> map[x.id]=x)
      if (mounted){ setCopies(c||[]); setBooksMap(map) }
    })()
    return ()=> mounted = false
  },[])

  return (
    <div>
      <h1>Exemplares</h1>
      <Link to="/registar-exemplar" className="btn">Registar exemplar</Link>
      <ul>
        {copies.map(c=>(<li key={c.id}>{c.code || ('#'+c.id)} — {booksMap[c.bookId]?.title || 'Livro '+c.bookId} — {c.available? 'Disponível':'Indisponível'}</li>))}
      </ul>
    </div>
  )
}
