import React, {useEffect, useState} from 'react'
import { Link } from 'react-router-dom'
import { dbGetAuthors, dbAddAuthor } from '../utils/db'

export default function ListAuthors(){
  const [authors, setAuthors] = useState([])
  useEffect(()=>{
    let mounted = true
    ;(async ()=>{
      const a = await dbGetAuthors()
      if (mounted) setAuthors(a||[])
    })()
    return ()=> mounted = false
  },[])

  return (
    <div>
      <h1>Autores</h1>
      <Link to="/registar-autor" className="btn">Registar novo autor</Link>
      <ul>
        {authors.map(a=>(<li key={a.id}>{a.name} <small>{a.country||''}</small></li>))}
      </ul>
    </div>
  )
}
