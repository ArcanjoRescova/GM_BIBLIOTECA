import React, {useState, useEffect} from 'react'
import { useNavigate } from 'react-router-dom'
import { dbAddCopy, dbGetBooks } from '../utils/db'

export default function RegisterExemplar(){
  const [bookId, setBookId] = useState('')
  const [code, setCode] = useState('')
  const [available, setAvailable] = useState(true)
  const navigate = useNavigate()
  const [books, setBooks] = useState([])

  useEffect(()=>{
    let mounted = true
    ;(async ()=>{
      const b = await dbGetBooks()
      if (mounted) setBooks(b||[])
    })()
    return ()=> mounted = false
  },[])

  async function submit(e){
    e.preventDefault()
    if (!bookId) return
    await dbAddCopy({bookId: Number(bookId), code, available})
    navigate('/')
  }

  return (
    <div>
      <h1>Registar exemplar</h1>
      <form onSubmit={submit} className="formgrid">
        <label>Livro<select value={bookId} onChange={e=>setBookId(e.target.value)} required>
          <option value="">— Selecionar —</option>
          {books.map(b=>(<option key={b.id} value={b.id}>{b.title}</option>))}
        </select></label>
        <label>Código<input value={code} onChange={e=>setCode(e.target.value)} /></label>
        <label>Disponível<select value={available? '1':'0'} onChange={e=>setAvailable(e.target.value==='1')}>
          <option value="1">Sim</option>
          <option value="0">Não</option>
        </select></label>
        <div className="actions"><button className="btn">Guardar</button></div>
      </form>
    </div>
  )
}
