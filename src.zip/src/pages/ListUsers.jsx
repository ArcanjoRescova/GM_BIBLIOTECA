import React, {useEffect, useState} from 'react'
import { Link } from 'react-router-dom'
import { dbGetUsers } from '../utils/db'

export default function ListUsers(){
  const [users, setUsers] = useState([])
  useEffect(()=>{
    let mounted = true
    ;(async ()=>{
      const u = await dbGetUsers()
      if (mounted) setUsers(u||[])
    })()
    return ()=> mounted = false
  },[])

  return (
    <div>
      <h1>Utentes</h1>
      <Link to="/registar-utente" className="btn">Registar utente</Link>
      <ul>
        {users.map(u=>(<li key={u.id}>{u.name}</li>))}
      </ul>
    </div>
  )
}
