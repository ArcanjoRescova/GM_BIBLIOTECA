import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom'
import { dbAddAuthor } from '../utils/db'

export default function RegisterAuthor(){
  const [name, setName] = useState('')
  const [country, setCountry] = useState('')
  const [msg, setMsg] = useState('')
  const navigate = useNavigate()

  async function submit(e){
    e.preventDefault()
    if (!name || !country) { setMsg('Preencha todos os campos obrigatórios.'); return }
    await dbAddAuthor({name,country})
    navigate('/registar-livro')
  }

  return (
    <div>
      <h1>Registar autor</h1>
      {msg && <div className="alert">{msg}</div>}
      <form onSubmit={submit} className="formgrid">
        <label>Nome<input value={name} onChange={e=>setName(e.target.value)} required/></label>
        <label>País<input value={country} onChange={e=>setCountry(e.target.value)} required/></label>
        <div className="actions"><button className="btn">Registar</button></div>
      </form>
    </div>
  )
}
