import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || ''
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || ''

let supabase = null
if (SUPABASE_URL && SUPABASE_ANON_KEY) {
  supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
}

const STORAGE_KEY = 'gm_biblioteca_v1'

function read(){
  try{ return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}') }catch(e){ return {} }
}
function write(data){ localStorage.setItem(STORAGE_KEY, JSON.stringify(data)) }
function ensure(){
  const d = read()
  if (!d.books) d.books = []
  if (!d.authors) d.authors = []
  if (!d.publishers) d.publishers = []
  if (!d.users) d.users = []
  if (!d.genres) d.genres = ['Ficção','Não-ficção','Romance','Infantil']
  if (!d.copies) d.copies = []
  if (!d.loans) d.loans = []
  if (!d.postals) d.postals = []
  write(d)
  return d
}

// Helper: if supabase configured use it, otherwise fallback to localStorage
async function useOrFallback(fnLocal, fnSupabase){
  if (supabase && fnSupabase) {
    try { return await fnSupabase() } catch(e){ console.warn('Supabase error, falling back to localStorage', e) }
  }
  return fnLocal()
}

// Exports: async API but local fallback remains synchronous
export async function dbGetHighlights(){
  return useOrFallback(
    ()=> ensure().books.slice(-12).reverse(),
    async ()=>{
      const { data, error } = await supabase.from('livro').select('li_cod,li_titulo,li_isbn,autor:autor(au_nome),genero:genero(ge_genero)').order('li_cod',{ascending:false}).limit(12)
      if (error) throw error
      return (data||[]).map(r=>({ id: r.li_cod, title: r.li_titulo, isbn: r.li_isbn, author: r.autor?.au_nome || '', genre: r.genero?.ge_genero || '' }))
    }
  )
}
export async function dbSearchBooks(q){
  return useOrFallback(
    ()=>{
      const d = ensure(); const ql = q.toLowerCase()
      return d.books.filter(b=> (b.title||'').toLowerCase().includes(ql) || (b.author||'').toLowerCase().includes(ql) || (b.isbn||'').toLowerCase().includes(ql))
    },
    async ()=>{
      const { data, error } = await supabase.from('livro').select('li_cod,li_titulo,li_isbn,autor:autor(au_nome),genero:genero(ge_genero)').or(`li_titulo.ilike.%${q}%,autor.au_nome.ilike.%${q}%,li_isbn.ilike.%${q}%`).limit(24).order('li_titulo')
      if (error) throw error
      return (data||[]).map(r=>({ id: r.li_cod, title: r.li_titulo, isbn: r.li_isbn, author: r.autor?.au_nome || '', genre: r.genero?.ge_genero || '' }))
    }
  )
}
export async function dbGetBookById(id){
  return useOrFallback(
    ()=> ensure().books.find(b=>b.id === id) || null,
    async ()=>{
      const { data, error } = await supabase.from('livro').select('li_titulo,li_isbn,li_ano,li_edicao,autor:autor(au_nome),editora:editora(ed_nome),genero:genero(ge_genero)').eq('li_cod', id).limit(1).single()
      if (error) throw error
      return data ? { title: data.li_titulo, isbn: data.li_isbn, year: data.li_ano, edition: data.li_edicao, author: data.autor?.au_nome, publisher: data.editora?.ed_nome, genre: data.genero?.ge_genero } : null
    }
  )
}
export async function dbAddBook(book){
  return useOrFallback(
    ()=>{
      const d = ensure(); const id = Date.now(); const record = { id, title: book.title, isbn: book.isbn, author: book.author, publisher: book.publisher, genre: book.genre, year: book.year, edition: book.edition }
      d.books.push(record); write(d); return record
    },
    async ()=>{
      const payload = { li_titulo: book.title, li_isbn: book.isbn, li_autor: book.author || null, li_editora: book.publisher || null, li_genero: book.genre, li_ano: book.year || null, li_edicao: book.edition || null }
      const { data, error } = await supabase.from('livro').insert(payload).select().single()
      if (error) throw error
      return { id: data.li_cod, title: data.li_titulo, isbn: data.li_isbn }
    }
  )
}
export async function dbGetAuthors(){
  return useOrFallback(()=> ensure().authors, async ()=>{
    const { data, error } = await supabase.from('autor').select('au_cod,au_nome').order('au_nome')
    if (error) throw error
    return (data||[]).map(r=>({ id: r.au_cod, name: r.au_nome }))
  })
}
export async function dbAddAuthor(a){
  return useOrFallback(
    ()=>{ const d=ensure(); const id=Date.now(); const rec={id,name:a.name,country:a.country}; d.authors.push(rec); write(d); return rec },
    async ()=>{ const { data, error } = await supabase.from('autor').insert({ au_nome: a.name, au_pais: a.country }).select().single(); if (error) throw error; return { id: data.au_cod, name: data.au_nome } }
  )
}
export async function dbGetPublishers(){
  return useOrFallback(()=> ensure().publishers, async ()=>{
    const { data, error } = await supabase.from('editora').select('ed_cod,ed_nome').order('ed_nome')
    if (error) throw error
    return (data||[]).map(r=>({ id: r.ed_cod, name: r.ed_nome }))
  })
}
export async function dbGetGenres(){
  return useOrFallback(()=> ensure().genres, async ()=>{
    const { data, error } = await supabase.from('genero').select('ge_genero').order('ge_genero')
    if (error) throw error
    return (data||[]).map(r=>r.ge_genero)
  })
}
export async function dbAddGenre(g){
  return useOrFallback(()=>{ const d=ensure(); if (!d.genres.includes(g)) d.genres.push(g); write(d); return g }, async ()=>{ const { data, error } = await supabase.from('genero').insert({ ge_genero: g }).select().single(); if (error) throw error; return data.ge_genero })
}
export async function dbAddPublisher(p){
  return useOrFallback(()=>{ const d=ensure(); const id=Date.now(); const rec={id,name:p.name}; d.publishers.push(rec); write(d); return rec }, async ()=>{ const { data, error } = await supabase.from('editora').insert({ ed_nome: p.name }).select().single(); if (error) throw error; return { id: data.ed_cod, name: data.ed_nome } })
}
export async function dbGetBooks(){
  return useOrFallback(()=> ensure().books, async ()=>{
    const { data, error } = await supabase.from('livro').select('li_cod,li_titulo,li_isbn,autor:autor(au_nome),genero:genero(ge_genero)').order('li_cod')
    if (error) throw error
    return (data||[]).map(r=>({ id: r.li_cod, title: r.li_titulo, isbn: r.li_isbn, author: r.autor?.au_nome || '', genre: r.genero?.ge_genero || '' }))
  })
}
export async function dbAddCopy(copy){
  return useOrFallback(()=>{ const d=ensure(); const id=Date.now(); const rec={id,bookId:copy.bookId,code:copy.code||null,available:!!copy.available}; d.copies.push(rec); write(d); return rec }, async ()=>{ const { data, error } = await supabase.from('livro_exemplar').insert({ lex_li_cod: copy.bookId, lex_codigo: copy.code, lex_disponivel: copy.available?1:0 }).select().single(); if (error) throw error; return { id: data.lex_cod, bookId: data.lex_li_cod, code: data.lex_codigo, available: !!data.lex_disponivel } })
}
export async function dbGetCopies(){
  return useOrFallback(()=> ensure().copies, async ()=>{ const { data, error } = await supabase.from('livro_exemplar').select('*'); if (error) throw error; return data })
}
export async function dbAddLoan(l){
  return useOrFallback(()=>{ const d=ensure(); const id=Date.now(); const rec={id,userId:l.userId,copyId:l.copyId,date:l.date}; d.loans.push(rec); const c=d.copies.find(x=>x.id===l.copyId); if(c) c.available=false; write(d); return rec }, async ()=>{ const { data, error } = await supabase.from('requisicao').insert({ rq_ut_cod: l.userId, rq_lex_cod: l.copyId, rq_data: l.date }).select().single(); if (error) throw error; // mark exemplar
  await supabase.from('livro_exemplar').update({ lex_disponivel: 0 }).eq('lex_cod', l.copyId)
  return { id: data.rq_cod, userId: data.rq_ut_cod, copyId: data.rq_lex_cod, date: data.rq_data }
  })
}
export async function dbGetUsers(){
  return useOrFallback(()=> ensure().users, async ()=>{ const { data, error } = await supabase.from('utente').select('ut_cod,ut_nome'); if (error) throw error; return (data||[]).map(r=>({ id: r.ut_cod, name: r.ut_nome })) })
}
export async function dbAddPostal(p){
  return useOrFallback(()=>{ const d=ensure(); const rec={code:p.code,locality:p.locality}; d.postals.push(rec); write(d); return rec }, async ()=>{ const { data, error } = await supabase.from('codigo_postal').insert({ cod_postal: p.code, cod_localidade: p.locality }).select().single(); if (error) throw error; return { code: data.cod_postal, locality: data.cod_localidade } })
}
export async function dbSummary(){
  return useOrFallback(()=>{ const d=ensure(); return { books:d.books.length, authors:d.authors.length, publishers:d.publishers.length, users:d.users.length, copies:d.copies.length, loans:d.loans.length } }, async ()=>{
    const counts = {}
    const q = async (table)=>{ const { count, error } = await supabase.from(table).select('*', { count: 'exact', head: true }); if (error) throw error; return count || 0 }
    counts.books = await q('livro')
    counts.authors = await q('autor')
    counts.publishers = await q('editora')
    counts.users = await q('utente')
    counts.copies = await q('livro_exemplar')
    counts.loans = await q('requisicao')
    return counts
  })
}
export async function dbAddUser(u){
  return useOrFallback(()=>{ const d=ensure(); const id=Date.now(); const rec={id,...u}; d.users.push(rec); write(d); return rec }, async ()=>{ const { data, error } = await supabase.from('utente').insert({ ut_nome: u.name, ut_nif: u.nif, ut_email: u.email, ut_tlm: u.phone, ut_morada: u.address, ut_cod_postal: u.postal }).select().single(); if (error) throw error; return { id: data.ut_cod, name: data.ut_nome } })
}
