import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Details from './pages/Details'
import RegisterBook from './pages/RegisterBook'
import RegisterAuthor from './pages/RegisterAuthor'
import RegisterUser from './pages/RegisterUser'
import RegisterGenre from './pages/RegisterGenre'
import RegisterPublisher from './pages/RegisterPublisher'
import RegisterExemplar from './pages/RegisterExemplar'
import RegisterLoan from './pages/RegisterLoan'
import RegisterPostal from './pages/RegisterPostal'
import ManageDb from './pages/ManageDb'
import ListAuthors from './pages/ListAuthors'
import ListPublishers from './pages/ListPublishers'
import ListUsers from './pages/ListUsers'
import ListCopies from './pages/ListCopies'

export default function App(){
  return (
    <div>
      <header className="top-banner">
        <div className="topbar-left">
          <button className="menu-btn">☰</button>
          <div className="brand">GINESTAL MACHADO</div>
        </div>
        <div className="topbar-right">NOME DA ESCOLA</div>
      </header>
      <div className="app-layout">
        <aside className="sidebar">
          <div className="sidebar-top">
            <div className="sidebar-brand">BIBLIOTÉCARIO</div>
          </div>
          <ul>
            <li><Link to="/">Catálogo</Link></li>
            <li><Link to="/registar-livro">Registar livro</Link></li>
            <li><Link to="/registar-autor">Registar autor</Link></li>
            <li><Link to="/registar-utente">Registar utente</Link></li>
            <li><Link to="/registar-genero">Género</Link></li>
            <li><Link to="/registar-editora">Editora</Link></li>
            <li><Link to="/registar-exemplar">Exemplar</Link></li>
            <li><Link to="/registar-emprestimo">Empréstimo</Link></li>
            <li><Link to="/registar-codigo-postal">Código postal</Link></li>
            <li><Link to="/gerir-bd">Gerir BD</Link></li>
            <li className="mt-sep"><strong>Listagens</strong></li>
            <li><Link to="/autores">Autores</Link></li>
            <li><Link to="/editoras">Editoras</Link></li>
            <li><Link to="/utentes">Utentes</Link></li>
            <li><Link to="/exemplares">Exemplares</Link></li>
          </ul>
        </aside>
        <main className="content container">
          <Routes>
            <Route path="/" element={<Home/>} />
            <Route path="/detalhes/:id" element={<Details/>} />
            <Route path="/registar-livro" element={<RegisterBook/>} />
            <Route path="/registar-autor" element={<RegisterAuthor/>} />
            <Route path="/registar-utente" element={<RegisterUser/>} />
            <Route path="/registar-genero" element={<RegisterGenre/>} />
            <Route path="/registar-editora" element={<RegisterPublisher/>} />
            <Route path="/registar-exemplar" element={<RegisterExemplar/>} />
            <Route path="/registar-emprestimo" element={<RegisterLoan/>} />
            <Route path="/registar-codigo-postal" element={<RegisterPostal/>} />
            <Route path="/gerir-bd" element={<ManageDb/>} />
            <Route path="/autores" element={<ListAuthors/>} />
            <Route path="/editoras" element={<ListPublishers/>} />
            <Route path="/utentes" element={<ListUsers/>} />
            <Route path="/exemplares" element={<ListCopies/>} />
          </Routes>
        </main>
      </div>
    </div>
  )
}
